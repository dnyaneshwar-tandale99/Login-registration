package com.example.EYSpringREST.service;

import com.example.EYSpringREST.entity.Users;
import com.example.EYSpringREST.repository.UserRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class userServiceImpl implements userDAO {
    private static final Logger LOGGER= LogManager.getLogger(userServiceImpl.class);
    @Autowired
    private UserRepository userRepository;
    ArrayList<Users> usersArrayList = new ArrayList<>();

    @Override
    public boolean isvalidUser(Users users) {
        if (users != null && users.getUname() != null && users.getPass() != null) {
            return users.getUname().equals("admin") && users.getPass().equals("admin123");
        } else {
            return false;
        }
    }

    @Override
    public void addUser(Users users) {
        userRepository.save(users);
        System.out.println("User added!!");
    }

    @Override
    public boolean findUser(int userId) {
       Optional<Users> findData=userRepository.findById(userId);
       if(findData.isPresent())
       {
           return true;
       }
       return false;
    }

    @Override
    public List<Users> loadUsers() {

        return (List<Users>) userRepository.findAll();
    }

    @Override
    public boolean deleteUser(int userId) {
        Optional<Users> findData=userRepository.findById(userId);
        if(findData.isPresent())
        {
            userRepository.deleteById(userId);
            return true;
        }
        return false;
    }

public List<Users> getAllUsers(Integer pageNo,Integer pageSize,String sortBy)
{
    Pageable pageable= PageRequest.of(pageNo,pageSize, Sort.by(sortBy));
    Page<Users> pageResult=userRepository.findAll(pageable);
    if(pageResult.hasContent()) {
        return pageResult.getContent();
    }else {
        return new ArrayList<Users>();
    }
}

}

