package com.example.EYSpringREST.controller;

import com.example.EYSpringREST.entity.Users;
import com.example.EYSpringREST.service.userDAO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/mainapp")
public class RestApp {
    private static final Logger LOGGER = LogManager.getLogger(RestApp.class);
    @Autowired
    private userDAO dao;

    @PostMapping("/login")
    public String loginValid(@RequestBody Users users) {
        LOGGER.info("inside the login Valid User method");
        if (dao.isvalidUser(users)) {
            return "Login Success";
        } else {
            return "Login Failure";
        }

    }

    @PostMapping("/register")
    public String registerUser(@RequestBody Users users) {
        LOGGER.info("inside the register User method");
        dao.addUser(users);
        return "User Added";
    }

    @GetMapping("/loadall")
    public List<Users> loadUsers(@RequestHeader(name = "X-COM-PERSIST", required = true) String headerName, @RequestHeader(name = "X-COM-LOCATION", defaultValue = "ASIA") String location) {
        LOGGER.info("inside the logUsers method");
        return dao.loadUsers();
    }

    @GetMapping("/find/{userId}")
    public String searchUser(@PathVariable("userId") int userId) {
        LOGGER.info("inside the Search User method");
        if (dao.findUser(userId)) {
            return userId + " found ";
        } else
            return "user not found...!";
    }

    @DeleteMapping("/delete/{userId}")
    public String deleteUser(@PathVariable("userId") int userId) {
        LOGGER.info("inside the delete User method");
        if (dao.deleteUser(userId)) {
            return userId + " found and deleted !!";
        } else
            return "user not found...!";
    }

    @GetMapping("/loadallPS")
    public ResponseEntity<List<Users>> loadUsersPS(
            @RequestParam(defaultValue = "0") Integer pageNo,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "userId") String sortBy

    ) {
        LOGGER.info("inside the load users for Pagination and Sorting method");
        List<Users> list = dao.getAllUsers(pageNo, pageSize, sortBy);
        return new ResponseEntity<List<Users>>(list, HttpStatus.OK);
    }
}
