package com.example.EYSpringREST.service;

import com.example.EYSpringREST.entity.Users;

import java.util.List;

public interface userDAO {
    public boolean isvalidUser(Users users);
    public void addUser(Users users);
    public boolean findUser(int userId);
    public List<Users> loadUsers();
    public boolean deleteUser(int userId);
    public List<Users> getAllUsers(Integer pageNo,Integer pageSize,String sortBy);
}
