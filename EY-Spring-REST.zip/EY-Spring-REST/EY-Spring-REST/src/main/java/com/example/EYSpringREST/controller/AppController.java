package com.example.EYSpringREST.controller;

import com.example.EYSpringREST.entity.Users;
import com.example.EYSpringREST.service.userDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@Controller
@RequestMapping("/mainapp")
public class AppController {
    @Autowired
    private userDAO  dao;

    @RequestMapping(path = "/welcome",method = RequestMethod.GET)
    @ResponseBody
    public String sayWelcome() {
        return "Welcome to REST";
    }
    @GetMapping("/login")
    public String login() {
        return "login";
    }
    @GetMapping("/register")
    public String register() {
        return "register";
    }
}
